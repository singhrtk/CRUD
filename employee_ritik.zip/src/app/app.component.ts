import { Component } from '@angular/core';
import {UsersService} from './users.service'


interface employee {
  id: Number;
  name: String;
  role: String;
  salary: Number;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'employees';
  emp : any= [];

  constructor(private user : UsersService){
    this.user.fetch_api().subscribe(emp =>{
      console.log(emp);
      this.emp = emp;
    }
      )
  }
}
