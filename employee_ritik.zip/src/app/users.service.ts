import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(private http :HttpClient) { }

  fetch_api(){
    let uri = "https://pxyv1qk9dd.execute-api.us-east-1.amazonaws.com/gdtc-test/employees";
    return this.http.get(uri);
  }
}
