import json
import boto3
from encoder import Coder
import ast
import pandas
from dataclasses import dataclass, field

db_name = 'gdtc'
dynamodb = boto3.resource('dynamodb')
gdtc_table = dynamodb.Table(db_name)


def lambda_handler(event, context):
    # print(event)
    # Methods :
    get = 'GET'
    post = 'POST'
    patch = 'PATCH'
    delete = 'DELETE'

    # fetch endpoints

    company = '/company'
    employees = '/employees'

    method = event['httpMethod']
    path = event['path']

    if method == get and path == company:
        return fetch_data(event['queryStringParameters']['id'])
    elif method == post and path == company:
        return add_data(json.loads(event['body']))
    elif method == delete and path == company:
        return deleteObject(event['queryStringParameters']['id'])
    elif method == patch and path == company:
        x = json.loads(event['body'])
        # print(x)
        # return patchmethod(x['id'], x['xkey'], x['xvalue'])
        return patchmethod(x['id'], x['name'], x['role'], x['salary'])
    elif method == get and path == employees:
        return getAllemployees()
    else:
        return get_response(404, 'Not Found method or url')


def get_response(status, body=None):
    try:
        resp = {
            'statusCode': status,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        }
        if body is not None:
            resp['body'] = json.dumps(body, cls=Coder)
        print(resp)
        return resp
    except Exception as e:
        print(e)


def add_data(inputdata):
    try:
        gdtc_table.put_item(Item=inputdata)
        return get_response(200, 'Data Saved.')
    except:
        return get_response(404, 'fail to fetch response from add_data')


def fetch_data(id):
    try:
        resp = gdtc_table.get_item(
            Key={'id': int(id)}
        )
        if 'Item' in resp:
            return get_response(200, resp['Item'])
        else:
            return get_response(404, 'Id Not found')
    except Exception as e:
        print('fail to fetch response from fetch_data')
        return get_response(404, 'fail to fetch response from fetch_data')


def deleteObject(id):
    try:
        resp = gdtc_table.delete_item(
            Key={
                'id': int(id)
            },
            ReturnValues='ALL_OLD'
        )
        return get_response(200, resp)
    except Exception as e:
        return get_response(404, 'Error while deleting the data')


def getAllemployees():
    try:
        resp = gdtc_table.scan()
        data = resp['Items']

        df = pandas.DataFrame(data)
        x = get_field_data(df)

        return get_responses(200, x.exposures)
    except:
        print('NA')


def patchmethod(id, name, role, salary):
    try:
        resp = gdtc_table.update_item(
            Key={
                'id': id
            },
            # UpdateExpression= 'set %s = :value' % key,
            UpdateExpression='SET #x = :val1, #y = :val2, #z = :val3',
            ExpressionAttributeValues={
                ':val1': name,
                ':val2': role,
                ':val3': salary
            },
            ExpressionAttributeNames={
                "#x": "name",
                "#y": "role",
                "#z": "salary",

            },
            ReturnValues='UPDATED_NEW'
        )

        body = {
            'resp': resp
        }

        df = pandas.DataFrame(body)
        x = get_field_data(df)

        return get_responses(200, x.exposures)
    except Exception as e:
        print(e)


def get_responses(status, body=None):
    try:
        resp = {
            'statusCode': status,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        }
        if body is not None:
            resp['body'] = json.dumps(body)

        return resp
    except Exception as e:
        print(e)


def get_field_data(dataframe):
    contents = ExposureData()
    contents.exposures = json.loads(dataframe.to_json(orient='records'))
    return contents


@dataclass
class ExposureData:
    exposures: str = ''